var classtrabalho_p_o_o__27967_1_1_category =
[
    [ "Category", "classtrabalho_p_o_o__27967_1_1_category.html#aeaf306790e0f4a3efd996d2a769de226", null ],
    [ "Category", "classtrabalho_p_o_o__27967_1_1_category.html#a585f41da594468e639fc8d7f10d84b09", null ],
    [ "Equals", "classtrabalho_p_o_o__27967_1_1_category.html#a281418febd9d5f834c9802be2c57a60f", null ],
    [ "Id", "classtrabalho_p_o_o__27967_1_1_category.html#ae4f15b6b9b966a88d9394a6fc91821f4", null ],
    [ "Name", "classtrabalho_p_o_o__27967_1_1_category.html#a45c06977f2a8d075df036876f80563ee", null ]
];