var dir_2febc12c3c491208b6bb30c417a778ab =
[
    [ "Campaign", "dir_03880beed948e9eebaf040adedab47f1.html", "dir_03880beed948e9eebaf040adedab47f1" ],
    [ "Category", "dir_7289ba53a0722adefe965269996cdba0.html", "dir_7289ba53a0722adefe965269996cdba0" ],
    [ "Client", "dir_bc2040cc2efaed7dc5a522603f9f4f2a.html", "dir_bc2040cc2efaed7dc5a522603f9f4f2a" ],
    [ "Interface", "dir_f84f82304bc49da86f24897bd622b49f.html", "dir_f84f82304bc49da86f24897bd622b49f" ],
    [ "Make", "dir_f0ef98ec13f4ac7be5aa4acc9b78c933.html", "dir_f0ef98ec13f4ac7be5aa4acc9b78c933" ],
    [ "obj", "dir_21def539f1d69d8ce34d1109b21bae1f.html", "dir_21def539f1d69d8ce34d1109b21bae1f" ],
    [ "Product", "dir_066ad889b8403b1e5905d944e6b9ecf3.html", "dir_066ad889b8403b1e5905d944e6b9ecf3" ],
    [ "Properties", "dir_42a2b74406edc9527991b889ab6139d5.html", "dir_42a2b74406edc9527991b889ab6139d5" ],
    [ "Sale", "dir_80ee2cc77e2300f9414356f29b1d5e0f.html", "dir_80ee2cc77e2300f9414356f29b1d5e0f" ],
    [ "Store", "dir_b2286b1e04d92cf71f1aebfb7de29548.html", "dir_b2286b1e04d92cf71f1aebfb7de29548" ],
    [ "Warranty", "dir_7e7b624bc0ee9e0983cf144ab435bbed.html", "dir_7e7b624bc0ee9e0983cf144ab435bbed" ],
    [ "BestSale.cs", "_best_sale_8cs.html", "_best_sale_8cs" ]
];