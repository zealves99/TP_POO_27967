var searchData=
[
  ['warranties_0',['warranties',['../classtrabalho_p_o_o__27967_1_1_warranties.html#ae090fc9a1555b3ff970d597eb99d1313',1,'trabalhoPOO_27967.Warranties.Warranties()'],['../classtrabalho_p_o_o__27967_1_1_warranties.html#abdbdf0faffe66a55799e1cd9bd079e7c',1,'trabalhoPOO_27967.Warranties.Warranties(List&lt; Warranty &gt; warrants)']]],
  ['warranty_1',['warranty',['../classtrabalho_p_o_o__27967_1_1_warranty.html#a3c79ee575f3d82a435a9e880a6335948',1,'trabalhoPOO_27967.Warranty.Warranty()'],['../classtrabalho_p_o_o__27967_1_1_warranty.html#ae6f2af18d3aa15eb373a803445def9de',1,'trabalhoPOO_27967.Warranty.Warranty(string prodID, int durationInYears, string conditions)']]],
  ['warrantyexpirationdate_2',['WarrantyExpirationDate',['../classtrabalho_p_o_o__27967_1_1_sale.html#a9cdd2dc055a7056da19b2415390a82e6',1,'trabalhoPOO_27967::Sale']]],
  ['warratyexpirationdateforproduct_3',['WarratyExpirationDateForProduct',['../classtrabalho_p_o_o__27967_1_1_products.html#a7ec91ea123a0aecc75e0bde122d4901a',1,'trabalhoPOO_27967::Products']]]
];
