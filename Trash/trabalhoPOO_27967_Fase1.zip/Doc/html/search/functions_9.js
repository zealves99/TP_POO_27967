var searchData=
[
  ['sale_0',['sale',['../classtrabalho_p_o_o__27967_1_1_sale.html#a8b963fd45e09a46b4df9cf73ea81436e',1,'trabalhoPOO_27967.Sale.Sale()'],['../classtrabalho_p_o_o__27967_1_1_sale.html#aaa8c18406a9ee99f8a4252ec3e241a40',1,'trabalhoPOO_27967.Sale.Sale(Client client, Products products, Campaign camp)']]],
  ['sales_1',['sales',['../classtrabalho_p_o_o__27967_1_1_sales.html#a4d69d5be085f7c544c1954cc5e0484ec',1,'trabalhoPOO_27967.Sales.Sales()'],['../classtrabalho_p_o_o__27967_1_1_sales.html#a1542e8167350e438a94051e79705a770',1,'trabalhoPOO_27967.Sales.Sales(List&lt; Sale &gt; sales)']]],
  ['searchproduct_2',['SearchProduct',['../classtrabalho_p_o_o__27967_1_1_products.html#a6c4b0721b9ee7386ecf2f3ca7816d299',1,'trabalhoPOO_27967::Products']]],
  ['store_3',['store',['../classtrabalho_p_o_o__27967_1_1_store_1_1_store.html#af4455e9b746e573819f13be16c1b0721',1,'trabalhoPOO_27967.Store.Store.Store()'],['../classtrabalho_p_o_o__27967_1_1_store_1_1_store.html#a79907e1a87b112f18b749fb4b1fafdd6',1,'trabalhoPOO_27967.Store.Store.Store(Clients cl, Products p, Sales s, Makes m, Categories c, Warranties w)']]]
];
