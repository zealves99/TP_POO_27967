var searchData=
[
  ['campaign_0',['campaign',['../classtrabalho_p_o_o__27967_1_1_campaign.html#a7aabf9addefbdd81a4b0aa925d72c3f8',1,'trabalhoPOO_27967.Campaign.Campaign()'],['../classtrabalho_p_o_o__27967_1_1_campaign.html#ad8dc5c4c4f1d83a19d51d39e7f04e183',1,'trabalhoPOO_27967.Campaign.Campaign(string name, decimal discount, DateTime startDate, DateTime endDate)']]],
  ['campaigns_1',['campaigns',['../classtrabalho_p_o_o__27967_1_1_campaigns.html#a97781980ad64b2dc990aeae6014b91e8',1,'trabalhoPOO_27967.Campaigns.Campaigns()'],['../classtrabalho_p_o_o__27967_1_1_campaigns.html#aede4c425b273ac7cd3af7c6c2c28c65c',1,'trabalhoPOO_27967.Campaigns.Campaigns(List&lt; Campaign &gt; p)']]],
  ['categories_2',['categories',['../classtrabalho_p_o_o__27967_1_1_categories.html#a54401cb219e7c82b916751cc2a842ffd',1,'trabalhoPOO_27967.Categories.Categories()'],['../classtrabalho_p_o_o__27967_1_1_categories.html#a3a07eaa5ba822d834ff0de7ceaea055a',1,'trabalhoPOO_27967.Categories.Categories(List&lt; Category &gt; cats)']]],
  ['category_3',['category',['../classtrabalho_p_o_o__27967_1_1_category.html#aeaf306790e0f4a3efd996d2a769de226',1,'trabalhoPOO_27967.Category.Category()'],['../classtrabalho_p_o_o__27967_1_1_category.html#a585f41da594468e639fc8d7f10d84b09',1,'trabalhoPOO_27967.Category.Category(string name)']]],
  ['client_4',['client',['../classtrabalho_p_o_o__27967_1_1_client.html#ae79131a1d8ab126a6c6ee819383be73f',1,'trabalhoPOO_27967.Client.Client()'],['../classtrabalho_p_o_o__27967_1_1_client.html#a1bb92d1181e9a8a7ef8e2c1f27a16504',1,'trabalhoPOO_27967.Client.Client(string n, string c)']]],
  ['clients_5',['Clients',['../classtrabalho_p_o_o__27967_1_1_clients.html#a328fcdf10d654e6066b551848c54eeec',1,'trabalhoPOO_27967::Clients']]]
];
