var searchData=
[
  ['campaign_0',['campaign',['../classtrabalho_p_o_o__27967_1_1_campaign.html',1,'trabalhoPOO_27967.Campaign'],['../classtrabalho_p_o_o__27967_1_1_campaign.html#a7aabf9addefbdd81a4b0aa925d72c3f8',1,'trabalhoPOO_27967.Campaign.Campaign()'],['../classtrabalho_p_o_o__27967_1_1_campaign.html#ad8dc5c4c4f1d83a19d51d39e7f04e183',1,'trabalhoPOO_27967.Campaign.Campaign(string name, decimal discount, DateTime startDate, DateTime endDate)']]],
  ['campaign_2ecs_1',['Campaign.cs',['../_campaign_8cs.html',1,'']]],
  ['campaigncount_2',['CampaignCount',['../classtrabalho_p_o_o__27967_1_1_campaign.html#ac843de804b9d01730c636081d0aee5ef',1,'trabalhoPOO_27967::Campaign']]],
  ['campaigns_3',['campaigns',['../classtrabalho_p_o_o__27967_1_1_campaigns.html',1,'trabalhoPOO_27967.Campaigns'],['../classtrabalho_p_o_o__27967_1_1_campaigns.html#a97781980ad64b2dc990aeae6014b91e8',1,'trabalhoPOO_27967.Campaigns.Campaigns()'],['../classtrabalho_p_o_o__27967_1_1_campaigns.html#aede4c425b273ac7cd3af7c6c2c28c65c',1,'trabalhoPOO_27967.Campaigns.Campaigns(List&lt; Campaign &gt; p)'],['../classtrabalho_p_o_o__27967_1_1_sale.html#a9d5e9df11addf81974e07801cd3e70dc',1,'trabalhoPOO_27967.Sale.Campaigns']]],
  ['campaigns_2ecs_4',['Campaigns.cs',['../_campaigns_8cs.html',1,'']]],
  ['camps_5',['Camps',['../classtrabalho_p_o_o__27967_1_1_campaigns.html#a8cf47ab3dd5e6370d4a7ce70bbe6bfff',1,'trabalhoPOO_27967::Campaigns']]],
  ['categories_6',['categories',['../classtrabalho_p_o_o__27967_1_1_categories.html',1,'trabalhoPOO_27967.Categories'],['../classtrabalho_p_o_o__27967_1_1_categories.html#a54401cb219e7c82b916751cc2a842ffd',1,'trabalhoPOO_27967.Categories.Categories()'],['../classtrabalho_p_o_o__27967_1_1_categories.html#a3a07eaa5ba822d834ff0de7ceaea055a',1,'trabalhoPOO_27967.Categories.Categories(List&lt; Category &gt; cats)']]],
  ['categories_2ecs_7',['Categories.cs',['../_categories_8cs.html',1,'']]],
  ['category_8',['category',['../classtrabalho_p_o_o__27967_1_1_category.html',1,'trabalhoPOO_27967.Category'],['../classtrabalho_p_o_o__27967_1_1_product.html#a91248f411f0a161c71c41935bc51af20',1,'trabalhoPOO_27967.Product.Category'],['../classtrabalho_p_o_o__27967_1_1_category.html#aeaf306790e0f4a3efd996d2a769de226',1,'trabalhoPOO_27967.Category.Category()'],['../classtrabalho_p_o_o__27967_1_1_category.html#a585f41da594468e639fc8d7f10d84b09',1,'trabalhoPOO_27967.Category.Category(string name)']]],
  ['category_2ecs_9',['Category.cs',['../_category_8cs.html',1,'']]],
  ['catlist_10',['CatList',['../classtrabalho_p_o_o__27967_1_1_store_1_1_store.html#a19ae6819a1416bfa370fb1a32eef5218',1,'trabalhoPOO_27967::Store::Store']]],
  ['cats_11',['Cats',['../classtrabalho_p_o_o__27967_1_1_categories.html#a59dc384d88b7e9604f94a736d4d99c2f',1,'trabalhoPOO_27967::Categories']]],
  ['client_12',['client',['../classtrabalho_p_o_o__27967_1_1_client.html',1,'trabalhoPOO_27967.Client'],['../classtrabalho_p_o_o__27967_1_1_sale.html#a9e7d84fcb634c0ed39209445346c25e3',1,'trabalhoPOO_27967.Sale.Client'],['../classtrabalho_p_o_o__27967_1_1_client.html#ae79131a1d8ab126a6c6ee819383be73f',1,'trabalhoPOO_27967.Client.Client()'],['../classtrabalho_p_o_o__27967_1_1_client.html#a1bb92d1181e9a8a7ef8e2c1f27a16504',1,'trabalhoPOO_27967.Client.Client(string n, string c)']]],
  ['client_2ecs_13',['Client.cs',['../_client_8cs.html',1,'']]],
  ['clientcount_14',['ClientCount',['../classtrabalho_p_o_o__27967_1_1_client.html#a52cde588e9e07b50cd8eb5d0e163f41a',1,'trabalhoPOO_27967::Client']]],
  ['clientid_15',['ClientID',['../classtrabalho_p_o_o__27967_1_1_client.html#a7908fcdc8cac6ac46540d4af2e5ec5aa',1,'trabalhoPOO_27967::Client']]],
  ['clientlist_16',['clientlist',['../classtrabalho_p_o_o__27967_1_1_clients.html#af4fa15f196e3ad08540fad1b12c5a17b',1,'trabalhoPOO_27967.Clients.ClientList'],['../classtrabalho_p_o_o__27967_1_1_store_1_1_store.html#aca697b091757878b46d74486f97eb251',1,'trabalhoPOO_27967.Store.Store.ClientLIst']]],
  ['clients_17',['clients',['../classtrabalho_p_o_o__27967_1_1_clients.html',1,'trabalhoPOO_27967.Clients'],['../classtrabalho_p_o_o__27967_1_1_clients.html#a328fcdf10d654e6066b551848c54eeec',1,'trabalhoPOO_27967.Clients.Clients()']]],
  ['clients_2ecs_18',['Clients.cs',['../_clients_8cs.html',1,'']]],
  ['conditions_19',['Conditions',['../classtrabalho_p_o_o__27967_1_1_warranty.html#a0aa6a3f6894f14c96ceb454e99f5c564',1,'trabalhoPOO_27967::Warranty']]],
  ['contact_20',['Contact',['../classtrabalho_p_o_o__27967_1_1_client.html#a8b129e2b56c2842dd70dc96999f6a829',1,'trabalhoPOO_27967::Client']]]
];
