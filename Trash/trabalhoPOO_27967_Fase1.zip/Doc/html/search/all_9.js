var searchData=
[
  ['name_0',['name',['../classtrabalho_p_o_o__27967_1_1_campaign.html#a6e74263525e33a178054d320d5ee1e33',1,'trabalhoPOO_27967.Campaign.Name'],['../classtrabalho_p_o_o__27967_1_1_category.html#a45c06977f2a8d075df036876f80563ee',1,'trabalhoPOO_27967.Category.Name'],['../classtrabalho_p_o_o__27967_1_1_client.html#a36b2d494ac70b9cb9ecc11bd9b5c7939',1,'trabalhoPOO_27967.Client.Name'],['../classtrabalho_p_o_o__27967_1_1_make.html#ad7d156e2c12f954ef255ca904ef1f168',1,'trabalhoPOO_27967.Make.Name']]]
];
