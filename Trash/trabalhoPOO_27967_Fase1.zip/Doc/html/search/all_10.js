var searchData=
[
  ['warranties_0',['warranties',['../classtrabalho_p_o_o__27967_1_1_warranties.html',1,'trabalhoPOO_27967.Warranties'],['../classtrabalho_p_o_o__27967_1_1_warranties.html#ae090fc9a1555b3ff970d597eb99d1313',1,'trabalhoPOO_27967.Warranties.Warranties()'],['../classtrabalho_p_o_o__27967_1_1_warranties.html#abdbdf0faffe66a55799e1cd9bd079e7c',1,'trabalhoPOO_27967.Warranties.Warranties(List&lt; Warranty &gt; warrants)']]],
  ['warranties_2ecs_1',['Warranties.cs',['../_warranties_8cs.html',1,'']]],
  ['warrantlist_2',['WarrantList',['../classtrabalho_p_o_o__27967_1_1_store_1_1_store.html#a3fc987ecddc3d25244ffc5054579e7ee',1,'trabalhoPOO_27967::Store::Store']]],
  ['warrants_3',['Warrants',['../classtrabalho_p_o_o__27967_1_1_warranties.html#ae7b82ac3cd0cb0f44c571e833dd527e7',1,'trabalhoPOO_27967::Warranties']]],
  ['warranty_4',['warranty',['../classtrabalho_p_o_o__27967_1_1_warranty.html',1,'trabalhoPOO_27967.Warranty'],['../classtrabalho_p_o_o__27967_1_1_product.html#a87e275ca127e9b85a28839cd8879bc98',1,'trabalhoPOO_27967.Product.Warranty'],['../classtrabalho_p_o_o__27967_1_1_warranty.html#a3c79ee575f3d82a435a9e880a6335948',1,'trabalhoPOO_27967.Warranty.Warranty()'],['../classtrabalho_p_o_o__27967_1_1_warranty.html#ae6f2af18d3aa15eb373a803445def9de',1,'trabalhoPOO_27967.Warranty.Warranty(string prodID, int durationInYears, string conditions)']]],
  ['warranty_2ecs_5',['Warranty.cs',['../_warranty_8cs.html',1,'']]],
  ['warrantyexpirationdate_6',['WarrantyExpirationDate',['../classtrabalho_p_o_o__27967_1_1_sale.html#a9cdd2dc055a7056da19b2415390a82e6',1,'trabalhoPOO_27967::Sale']]],
  ['warratyexpirationdateforproduct_7',['WarratyExpirationDateForProduct',['../classtrabalho_p_o_o__27967_1_1_products.html#a7ec91ea123a0aecc75e0bde122d4901a',1,'trabalhoPOO_27967::Products']]]
];
