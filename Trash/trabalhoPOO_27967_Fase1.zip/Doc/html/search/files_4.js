var searchData=
[
  ['ilistmanagement_2ecs_0',['IListManagement.cs',['../_i_list_management_8cs.html',1,'']]]
];
