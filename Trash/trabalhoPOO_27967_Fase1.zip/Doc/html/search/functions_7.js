var searchData=
[
  ['product_0',['product',['../classtrabalho_p_o_o__27967_1_1_product.html#ac61138fdeb8b5f7f65e3a1746e40ff8f',1,'trabalhoPOO_27967.Product.Product()'],['../classtrabalho_p_o_o__27967_1_1_product.html#a4823c8970508ac357667e150404c2ddf',1,'trabalhoPOO_27967.Product.Product(string reff, decimal pri, Warranty war, Make ma, Category cat)']]],
  ['products_1',['products',['../classtrabalho_p_o_o__27967_1_1_products.html#a1fffd88356d5d671738b9360d066bcba',1,'trabalhoPOO_27967.Products.Products()'],['../classtrabalho_p_o_o__27967_1_1_products.html#a474679b02593808209ecd7bd827f2259',1,'trabalhoPOO_27967.Products.Products(List&lt; Product &gt; products)']]]
];
