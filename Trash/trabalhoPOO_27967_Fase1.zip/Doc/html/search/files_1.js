var searchData=
[
  ['assemblyinfo_2ecs_0',['AssemblyInfo.cs',['../_assembly_info_8cs.html',1,'']]]
];
