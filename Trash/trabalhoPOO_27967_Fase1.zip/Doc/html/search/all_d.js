var searchData=
[
  ['sale_0',['sale',['../classtrabalho_p_o_o__27967_1_1_sale.html',1,'trabalhoPOO_27967.Sale'],['../classtrabalho_p_o_o__27967_1_1_sale.html#a8b963fd45e09a46b4df9cf73ea81436e',1,'trabalhoPOO_27967.Sale.Sale()'],['../classtrabalho_p_o_o__27967_1_1_sale.html#aaa8c18406a9ee99f8a4252ec3e241a40',1,'trabalhoPOO_27967.Sale.Sale(Client client, Products products, Campaign camp)']]],
  ['sale_2ecs_1',['Sale.cs',['../_sale_8cs.html',1,'']]],
  ['saledate_2',['SaleDate',['../classtrabalho_p_o_o__27967_1_1_sale.html#a54f048c0abf036d49fb4b152290f2e01',1,'trabalhoPOO_27967::Sale']]],
  ['salelist_3',['SaleList',['../classtrabalho_p_o_o__27967_1_1_store_1_1_store.html#af70bdc8006dc38f10a7f2a3862a613c4',1,'trabalhoPOO_27967::Store::Store']]],
  ['sales_4',['sales',['../classtrabalho_p_o_o__27967_1_1_sales.html',1,'trabalhoPOO_27967.Sales'],['../classtrabalho_p_o_o__27967_1_1_sales.html#a4d69d5be085f7c544c1954cc5e0484ec',1,'trabalhoPOO_27967.Sales.Sales()'],['../classtrabalho_p_o_o__27967_1_1_sales.html#a1542e8167350e438a94051e79705a770',1,'trabalhoPOO_27967.Sales.Sales(List&lt; Sale &gt; sales)']]],
  ['sales_2ecs_5',['Sales.cs',['../_sales_8cs.html',1,'']]],
  ['salesstored_6',['SalesStored',['../classtrabalho_p_o_o__27967_1_1_sales.html#a5b2b0af9081d6b50d6a1027a7226376c',1,'trabalhoPOO_27967::Sales']]],
  ['searchproduct_7',['SearchProduct',['../classtrabalho_p_o_o__27967_1_1_products.html#a6c4b0721b9ee7386ecf2f3ca7816d299',1,'trabalhoPOO_27967::Products']]],
  ['startdate_8',['StartDate',['../classtrabalho_p_o_o__27967_1_1_campaign.html#a9581bc6e20941b81d9511f21233b5513',1,'trabalhoPOO_27967::Campaign']]],
  ['stock_9',['Stock',['../classtrabalho_p_o_o__27967_1_1_product.html#a018322d11e09df59317b7ee8c014a1f1',1,'trabalhoPOO_27967::Product']]],
  ['store_10',['store',['../classtrabalho_p_o_o__27967_1_1_store_1_1_store.html',1,'trabalhoPOO_27967.Store.Store'],['../classtrabalho_p_o_o__27967_1_1_store_1_1_store.html#af4455e9b746e573819f13be16c1b0721',1,'trabalhoPOO_27967.Store.Store.Store()'],['../classtrabalho_p_o_o__27967_1_1_store_1_1_store.html#a79907e1a87b112f18b749fb4b1fafdd6',1,'trabalhoPOO_27967.Store.Store.Store(Clients cl, Products p, Sales s, Makes m, Categories c, Warranties w)']]],
  ['store_2ecs_11',['Store.cs',['../_store_8cs.html',1,'']]]
];
