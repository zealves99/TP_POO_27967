var searchData=
[
  ['ilistmanagement_0',['IListManagement',['../interfacetrabalho_p_o_o__27967_1_1_interface_1_1_i_list_management.html',1,'trabalhoPOO_27967::Interface']]]
];
