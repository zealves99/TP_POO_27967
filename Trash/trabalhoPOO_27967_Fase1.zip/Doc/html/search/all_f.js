var searchData=
[
  ['valueinposition_0',['ValueInPosition',['../classtrabalho_p_o_o__27967_1_1_products.html#aaecad6a42d48c6a76d32fda436a2cc12',1,'trabalhoPOO_27967::Products']]],
  ['verifyapplicability_1',['VerifyApplicability',['../classtrabalho_p_o_o__27967_1_1_campaign.html#ab53a832c0be2a8573c6ea3734d6e18ba',1,'trabalhoPOO_27967::Campaign']]]
];
