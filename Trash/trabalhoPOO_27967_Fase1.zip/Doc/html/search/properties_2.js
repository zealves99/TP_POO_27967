var searchData=
[
  ['enddate_0',['EndDate',['../classtrabalho_p_o_o__27967_1_1_campaign.html#a3e6630bde22b7acd3fc92b7e639440dc',1,'trabalhoPOO_27967::Campaign']]]
];
