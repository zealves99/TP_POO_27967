var searchData=
[
  ['insertproductonsale_0',['InsertProductOnSale',['../classtrabalho_p_o_o__27967_1_1_sale.html#a490a170d965d4db25233bb14b7cd9df1',1,'trabalhoPOO_27967::Sale']]]
];
