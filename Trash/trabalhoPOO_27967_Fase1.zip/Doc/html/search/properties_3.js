var searchData=
[
  ['id_0',['id',['../classtrabalho_p_o_o__27967_1_1_make.html#a9ce429555f1a6a81614cd19e7c6a8ec2',1,'trabalhoPOO_27967.Make.ID'],['../classtrabalho_p_o_o__27967_1_1_campaign.html#a35d061bb738341b9cc8be5e1303f07d0',1,'trabalhoPOO_27967.Campaign.Id'],['../classtrabalho_p_o_o__27967_1_1_category.html#ae4f15b6b9b966a88d9394a6fc91821f4',1,'trabalhoPOO_27967.Category.Id'],['../classtrabalho_p_o_o__27967_1_1_sale.html#a89c992ccc396a89149b36b8a5c632a80',1,'trabalhoPOO_27967.Sale.Id']]]
];
