var searchData=
[
  ['getclient_0',['GetClient',['../classtrabalho_p_o_o__27967_1_1_clients.html#a27d0e7890e398b650937643fc57af8e2',1,'trabalhoPOO_27967::Clients']]],
  ['getsale_1',['GetSale',['../classtrabalho_p_o_o__27967_1_1_sales.html#a07c8656840c891411c07d7f27537b966',1,'trabalhoPOO_27967::Sales']]]
];
