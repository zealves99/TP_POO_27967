var interfacetrabalho_p_o_o__27967_1_1_interface_1_1_i_list_management =
[
    [ "Add", "interfacetrabalho_p_o_o__27967_1_1_interface_1_1_i_list_management.html#ab42dacc3ccfa608fd4fee1f9883149c9", null ],
    [ "Exist", "interfacetrabalho_p_o_o__27967_1_1_interface_1_1_i_list_management.html#ae6a36e9d3990a49abbf56519864aefa5", null ],
    [ "Remove", "interfacetrabalho_p_o_o__27967_1_1_interface_1_1_i_list_management.html#a08db8db0c2163d359a6c0d1ebd74770c", null ]
];