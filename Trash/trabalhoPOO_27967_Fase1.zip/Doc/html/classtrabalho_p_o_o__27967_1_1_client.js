var classtrabalho_p_o_o__27967_1_1_client =
[
    [ "Client", "classtrabalho_p_o_o__27967_1_1_client.html#ae79131a1d8ab126a6c6ee819383be73f", null ],
    [ "Client", "classtrabalho_p_o_o__27967_1_1_client.html#a1bb92d1181e9a8a7ef8e2c1f27a16504", null ],
    [ "Equals", "classtrabalho_p_o_o__27967_1_1_client.html#abc82a940efddbba52ae1098d597343d5", null ],
    [ "ToString", "classtrabalho_p_o_o__27967_1_1_client.html#ae5038206d2255374c562b45d83937d5e", null ],
    [ "ClientID", "classtrabalho_p_o_o__27967_1_1_client.html#a7908fcdc8cac6ac46540d4af2e5ec5aa", null ],
    [ "Contact", "classtrabalho_p_o_o__27967_1_1_client.html#a8b129e2b56c2842dd70dc96999f6a829", null ],
    [ "Name", "classtrabalho_p_o_o__27967_1_1_client.html#a36b2d494ac70b9cb9ecc11bd9b5c7939", null ]
];