var namespacetrabalho_p_o_o__27967_1_1_interface =
[
    [ "IListManagement", "interfacetrabalho_p_o_o__27967_1_1_interface_1_1_i_list_management.html", "interfacetrabalho_p_o_o__27967_1_1_interface_1_1_i_list_management" ]
];