var classtrabalho_p_o_o__27967_1_1_sales =
[
    [ "Sales", "classtrabalho_p_o_o__27967_1_1_sales.html#a4d69d5be085f7c544c1954cc5e0484ec", null ],
    [ "Sales", "classtrabalho_p_o_o__27967_1_1_sales.html#a1542e8167350e438a94051e79705a770", null ],
    [ "Add", "classtrabalho_p_o_o__27967_1_1_sales.html#a472d8cb3f41ed335eb2d47e76b2924d5", null ],
    [ "Exist", "classtrabalho_p_o_o__27967_1_1_sales.html#aa73c7a13ac6e3ffe286d1b4017817551", null ],
    [ "GetSale", "classtrabalho_p_o_o__27967_1_1_sales.html#a07c8656840c891411c07d7f27537b966", null ],
    [ "Remove", "classtrabalho_p_o_o__27967_1_1_sales.html#afb4a44c00fee7e8b0412b87f4dda4e22", null ],
    [ "SalesStored", "classtrabalho_p_o_o__27967_1_1_sales.html#a5b2b0af9081d6b50d6a1027a7226376c", null ]
];