var hierarchy =
[
    [ "trabalhoPOO_27967.BestSale", "classtrabalho_p_o_o__27967_1_1_best_sale.html", null ],
    [ "trabalhoPOO_27967.Campaign", "classtrabalho_p_o_o__27967_1_1_campaign.html", null ],
    [ "trabalhoPOO_27967.Category", "classtrabalho_p_o_o__27967_1_1_category.html", null ],
    [ "trabalhoPOO_27967.Client", "classtrabalho_p_o_o__27967_1_1_client.html", null ],
    [ "trabalhoPOO_27967.Interface.IListManagement", "interfacetrabalho_p_o_o__27967_1_1_interface_1_1_i_list_management.html", [
      [ "trabalhoPOO_27967.Campaigns", "classtrabalho_p_o_o__27967_1_1_campaigns.html", null ],
      [ "trabalhoPOO_27967.Categories", "classtrabalho_p_o_o__27967_1_1_categories.html", null ],
      [ "trabalhoPOO_27967.Clients", "classtrabalho_p_o_o__27967_1_1_clients.html", null ],
      [ "trabalhoPOO_27967.Makes", "classtrabalho_p_o_o__27967_1_1_makes.html", null ],
      [ "trabalhoPOO_27967.Products", "classtrabalho_p_o_o__27967_1_1_products.html", null ],
      [ "trabalhoPOO_27967.Sales", "classtrabalho_p_o_o__27967_1_1_sales.html", null ],
      [ "trabalhoPOO_27967.Warranties", "classtrabalho_p_o_o__27967_1_1_warranties.html", null ]
    ] ],
    [ "trabalhoPOO_27967.Make", "classtrabalho_p_o_o__27967_1_1_make.html", null ],
    [ "trabalhoPOO_27967.Product", "classtrabalho_p_o_o__27967_1_1_product.html", null ],
    [ "trabalhoPOO_27967.Sale", "classtrabalho_p_o_o__27967_1_1_sale.html", null ],
    [ "trabalhoPOO_27967.Store.Store", "classtrabalho_p_o_o__27967_1_1_store_1_1_store.html", null ],
    [ "trabalhoPOO_27967.Warranty", "classtrabalho_p_o_o__27967_1_1_warranty.html", null ]
];