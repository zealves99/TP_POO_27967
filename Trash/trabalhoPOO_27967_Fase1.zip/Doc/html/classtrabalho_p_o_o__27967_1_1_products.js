var classtrabalho_p_o_o__27967_1_1_products =
[
    [ "Products", "classtrabalho_p_o_o__27967_1_1_products.html#a1fffd88356d5d671738b9360d066bcba", null ],
    [ "Products", "classtrabalho_p_o_o__27967_1_1_products.html#a474679b02593808209ecd7bd827f2259", null ],
    [ "Add", "classtrabalho_p_o_o__27967_1_1_products.html#aa88f9e573377d1d38646662e632d4a4f", null ],
    [ "Exist", "classtrabalho_p_o_o__27967_1_1_products.html#a04a80cffcff1220ff623fa142d7696dd", null ],
    [ "Remove", "classtrabalho_p_o_o__27967_1_1_products.html#a70cc373ea371ce5338c6f2b8034040ee", null ],
    [ "SearchProduct", "classtrabalho_p_o_o__27967_1_1_products.html#a6c4b0721b9ee7386ecf2f3ca7816d299", null ],
    [ "ToString", "classtrabalho_p_o_o__27967_1_1_products.html#a1d5ad4db24efaa06591ca5f348945396", null ],
    [ "TotalPrice", "classtrabalho_p_o_o__27967_1_1_products.html#ad24e9aee05588a3dfca00c0cf7cf78cc", null ],
    [ "ValueInPosition", "classtrabalho_p_o_o__27967_1_1_products.html#aaecad6a42d48c6a76d32fda436a2cc12", null ],
    [ "WarratyExpirationDateForProduct", "classtrabalho_p_o_o__27967_1_1_products.html#a7ec91ea123a0aecc75e0bde122d4901a", null ],
    [ "Prods", "classtrabalho_p_o_o__27967_1_1_products.html#ab3b97b22d2afc9f517939c55ee7da816", null ]
];