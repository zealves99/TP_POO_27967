var classtrabalho_p_o_o__27967_1_1_campaigns =
[
    [ "Campaigns", "classtrabalho_p_o_o__27967_1_1_campaigns.html#a97781980ad64b2dc990aeae6014b91e8", null ],
    [ "Campaigns", "classtrabalho_p_o_o__27967_1_1_campaigns.html#aede4c425b273ac7cd3af7c6c2c28c65c", null ],
    [ "Add", "classtrabalho_p_o_o__27967_1_1_campaigns.html#a160b21ef64450077b0dce7583ade6629", null ],
    [ "Exist", "classtrabalho_p_o_o__27967_1_1_campaigns.html#aeeb5c96f0e977cf13cd1e3bb57c569cc", null ],
    [ "Remove", "classtrabalho_p_o_o__27967_1_1_campaigns.html#a6e8052eaf5987adbdd21971d8294c1d6", null ],
    [ "Camps", "classtrabalho_p_o_o__27967_1_1_campaigns.html#a8cf47ab3dd5e6370d4a7ce70bbe6bfff", null ]
];