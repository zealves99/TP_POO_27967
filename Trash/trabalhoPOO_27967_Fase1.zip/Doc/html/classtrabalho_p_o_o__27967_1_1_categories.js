var classtrabalho_p_o_o__27967_1_1_categories =
[
    [ "Categories", "classtrabalho_p_o_o__27967_1_1_categories.html#a54401cb219e7c82b916751cc2a842ffd", null ],
    [ "Categories", "classtrabalho_p_o_o__27967_1_1_categories.html#a3a07eaa5ba822d834ff0de7ceaea055a", null ],
    [ "Add", "classtrabalho_p_o_o__27967_1_1_categories.html#a3c3e06e65eea6de871239dc0304e0975", null ],
    [ "Exist", "classtrabalho_p_o_o__27967_1_1_categories.html#a82f06c789bd595e41f7cabeac48fa7d3", null ],
    [ "Remove", "classtrabalho_p_o_o__27967_1_1_categories.html#a9b3d18e9efa088cb63cea6857e23cb19", null ],
    [ "Cats", "classtrabalho_p_o_o__27967_1_1_categories.html#a59dc384d88b7e9604f94a736d4d99c2f", null ]
];