var namespaces_dup =
[
    [ "trabalhoPOO_27967", "namespacetrabalho_p_o_o__27967.html", "namespacetrabalho_p_o_o__27967" ]
];