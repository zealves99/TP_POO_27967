var classtrabalho_p_o_o__27967_1_1_clients =
[
    [ "Clients", "classtrabalho_p_o_o__27967_1_1_clients.html#a328fcdf10d654e6066b551848c54eeec", null ],
    [ "Add", "classtrabalho_p_o_o__27967_1_1_clients.html#a013314110936901e914f07ea22523667", null ],
    [ "Exist", "classtrabalho_p_o_o__27967_1_1_clients.html#acbb17687303e700ca54e3f93bdfc8902", null ],
    [ "GetClient", "classtrabalho_p_o_o__27967_1_1_clients.html#a27d0e7890e398b650937643fc57af8e2", null ],
    [ "Remove", "classtrabalho_p_o_o__27967_1_1_clients.html#a63e3db1ed71a4f889f6ba8ea7771dd90", null ],
    [ "ClientList", "classtrabalho_p_o_o__27967_1_1_clients.html#af4fa15f196e3ad08540fad1b12c5a17b", null ]
];