var dir_f86347ca1850f8625640a75b49ddda5a =
[
    [ ".NETFramework,Version=v4.7.2.AssemblyAttributes.cs", "_8_n_e_t_framework_00_version_0av4_87_82_8_assembly_attributes_8cs.html", null ]
];