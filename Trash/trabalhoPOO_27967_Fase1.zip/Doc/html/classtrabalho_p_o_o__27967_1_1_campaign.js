var classtrabalho_p_o_o__27967_1_1_campaign =
[
    [ "Campaign", "classtrabalho_p_o_o__27967_1_1_campaign.html#a7aabf9addefbdd81a4b0aa925d72c3f8", null ],
    [ "Campaign", "classtrabalho_p_o_o__27967_1_1_campaign.html#ad8dc5c4c4f1d83a19d51d39e7f04e183", null ],
    [ "Equals", "classtrabalho_p_o_o__27967_1_1_campaign.html#ac5c0122cf1a33776aab9f916a82a98e4", null ],
    [ "CampaignCount", "classtrabalho_p_o_o__27967_1_1_campaign.html#ac843de804b9d01730c636081d0aee5ef", null ],
    [ "Discount", "classtrabalho_p_o_o__27967_1_1_campaign.html#a5003da7c2b0875d4da86b494df362854", null ],
    [ "EndDate", "classtrabalho_p_o_o__27967_1_1_campaign.html#a3e6630bde22b7acd3fc92b7e639440dc", null ],
    [ "Id", "classtrabalho_p_o_o__27967_1_1_campaign.html#a35d061bb738341b9cc8be5e1303f07d0", null ],
    [ "Name", "classtrabalho_p_o_o__27967_1_1_campaign.html#a6e74263525e33a178054d320d5ee1e33", null ],
    [ "StartDate", "classtrabalho_p_o_o__27967_1_1_campaign.html#a9581bc6e20941b81d9511f21233b5513", null ]
];