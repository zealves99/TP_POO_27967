var _client_8cs =
[
    [ "trabalhoPOO_27967.Client", "classtrabalho_p_o_o__27967_1_1_client.html", "classtrabalho_p_o_o__27967_1_1_client" ]
];