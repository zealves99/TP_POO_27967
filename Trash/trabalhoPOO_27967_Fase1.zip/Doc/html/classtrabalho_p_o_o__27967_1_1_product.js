var classtrabalho_p_o_o__27967_1_1_product =
[
    [ "Product", "classtrabalho_p_o_o__27967_1_1_product.html#ac61138fdeb8b5f7f65e3a1746e40ff8f", null ],
    [ "Product", "classtrabalho_p_o_o__27967_1_1_product.html#a4823c8970508ac357667e150404c2ddf", null ],
    [ "Equals", "classtrabalho_p_o_o__27967_1_1_product.html#a027d297845f1f1bc45a4fabb07924205", null ],
    [ "ToString", "classtrabalho_p_o_o__27967_1_1_product.html#a539cf4a56701eda41cb33e96fc17b8ea", null ],
    [ "Category", "classtrabalho_p_o_o__27967_1_1_product.html#a91248f411f0a161c71c41935bc51af20", null ],
    [ "Make", "classtrabalho_p_o_o__27967_1_1_product.html#a6105fdcd708cf01c94b15e88b6ab5e1e", null ],
    [ "Price", "classtrabalho_p_o_o__27967_1_1_product.html#ac2cb36ab6a0ce5a14ecde2bd83f39863", null ],
    [ "Reference", "classtrabalho_p_o_o__27967_1_1_product.html#aed4ca8ecd0e063ebfb0de85f57477c70", null ],
    [ "Stock", "classtrabalho_p_o_o__27967_1_1_product.html#a018322d11e09df59317b7ee8c014a1f1", null ],
    [ "Warranty", "classtrabalho_p_o_o__27967_1_1_product.html#a87e275ca127e9b85a28839cd8879bc98", null ]
];