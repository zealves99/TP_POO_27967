var _campaigns_8cs =
[
    [ "trabalhoPOO_27967.Campaigns", "classtrabalho_p_o_o__27967_1_1_campaigns.html", "classtrabalho_p_o_o__27967_1_1_campaigns" ]
];