var classtrabalho_p_o_o__27967_1_1_sale =
[
    [ "Sale", "classtrabalho_p_o_o__27967_1_1_sale.html#a8b963fd45e09a46b4df9cf73ea81436e", null ],
    [ "Sale", "classtrabalho_p_o_o__27967_1_1_sale.html#aaa8c18406a9ee99f8a4252ec3e241a40", null ],
    [ "Equals", "classtrabalho_p_o_o__27967_1_1_sale.html#ac2a3312e994cc30e1febd7cf8f0b7e75", null ],
    [ "ExistProductOnSale", "classtrabalho_p_o_o__27967_1_1_sale.html#a3dd56154f8bee5eb6f74b12308829269", null ],
    [ "InsertProductOnSale", "classtrabalho_p_o_o__27967_1_1_sale.html#a490a170d965d4db25233bb14b7cd9df1", null ],
    [ "RemoveProductFromSale", "classtrabalho_p_o_o__27967_1_1_sale.html#a8ea1f0e768ba785fe4cb671bf5fa7bb9", null ],
    [ "ToString", "classtrabalho_p_o_o__27967_1_1_sale.html#aaa94e8e685b46538f39c9350c52efc40", null ],
    [ "TotalPrice", "classtrabalho_p_o_o__27967_1_1_sale.html#a23c67b9b3c7153f6a0640e3d766f74ba", null ],
    [ "WarrantyExpirationDate", "classtrabalho_p_o_o__27967_1_1_sale.html#a9cdd2dc055a7056da19b2415390a82e6", null ],
    [ "Campaigns", "classtrabalho_p_o_o__27967_1_1_sale.html#a9d5e9df11addf81974e07801cd3e70dc", null ],
    [ "Client", "classtrabalho_p_o_o__27967_1_1_sale.html#a9e7d84fcb634c0ed39209445346c25e3", null ],
    [ "Id", "classtrabalho_p_o_o__27967_1_1_sale.html#a89c992ccc396a89149b36b8a5c632a80", null ],
    [ "Products", "classtrabalho_p_o_o__27967_1_1_sale.html#a974f7167b2226b03aad5f6689b5a1786", null ],
    [ "SaleDate", "classtrabalho_p_o_o__27967_1_1_sale.html#a54f048c0abf036d49fb4b152290f2e01", null ],
    [ "TotPrice", "classtrabalho_p_o_o__27967_1_1_sale.html#af5aeaaf4c41d838dd897a53408bdcbd3", null ]
];