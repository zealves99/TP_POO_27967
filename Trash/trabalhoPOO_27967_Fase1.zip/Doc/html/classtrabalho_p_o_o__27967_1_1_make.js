var classtrabalho_p_o_o__27967_1_1_make =
[
    [ "Make", "classtrabalho_p_o_o__27967_1_1_make.html#ac7361aaf6e238cd128bc74a617771b65", null ],
    [ "Make", "classtrabalho_p_o_o__27967_1_1_make.html#a18535ff784fbd690ce11153013d80728", null ],
    [ "Equals", "classtrabalho_p_o_o__27967_1_1_make.html#a558322c9057c0cc85d399fcb10019ac5", null ],
    [ "ToString", "classtrabalho_p_o_o__27967_1_1_make.html#ab919e0e984621eea64b4147f14763a82", null ],
    [ "ID", "classtrabalho_p_o_o__27967_1_1_make.html#a9ce429555f1a6a81614cd19e7c6a8ec2", null ],
    [ "Name", "classtrabalho_p_o_o__27967_1_1_make.html#ad7d156e2c12f954ef255ca904ef1f168", null ]
];