var dir_80ee2cc77e2300f9414356f29b1d5e0f =
[
    [ "Sale.cs", "_sale_8cs.html", "_sale_8cs" ],
    [ "Sales.cs", "_sales_8cs.html", "_sales_8cs" ]
];